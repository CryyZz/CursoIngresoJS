function mostrar()
{
    var edad;

    var estado;

    edad = parseInt(document.getElementById("edad").value);

    estado = document.getElementById("estadoCivil").value;

    //document.getElementById("estadoCivil").value = estado;

    if(edad < 18 && estado != "Soltero")
    {
        alert("Es muy pequeño para NO ser soltero")     
    }
}