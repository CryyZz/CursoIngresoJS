function mostrar()
{
	Math.floor((Math.random() * 10) + 1);

	alert(Math.random);
}